DROP DATABASE IF EXISTS election;
CREATE DATABASE election;
USE election;
